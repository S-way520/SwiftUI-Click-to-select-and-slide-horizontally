import SwiftUI

struct HelloWorld: View {
    var body: some View {
        ScrollView(.horizontal){
            HStack {
                VStack {
                    Image(systemName: "globe")
                        .imageScale(.large)
                        .foregroundColor(.accentColor)
                    Text("Hello, world!")
                }
                .padding(10)
                VStack {
                    Image(systemName: "globe")
                        .imageScale(.large)
                        .foregroundColor(.accentColor)
                    Text("Hello, Friend!")
                }
                .padding(10)
            }
        }
    }
}
